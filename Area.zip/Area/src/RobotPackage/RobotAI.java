package RobotPackage;

public interface RobotAI {
   void runAI(RobotControl rc);
}
